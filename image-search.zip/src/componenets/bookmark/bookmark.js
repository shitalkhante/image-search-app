

export const Bookmark =(props)=>{
   
    return(
        <div style={{display:"flex",flexDirection:"row",flexWrap:"wrap"}}>
            {props.bookmark.map((d)=>{
                <img src="d" alt="img"/>
            })}
        </div>
    )
}